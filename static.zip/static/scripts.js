let currentSlide = 0;

function showSlides(n) {
    const slides = document.querySelector('.slider-container');
    const totalSlides = slides.children.length;

    currentSlide = (n + totalSlides) % totalSlides;
    slides.style.transform = `translateX(${-currentSlide * 100}%)`;
}

document.querySelector('.prev').addEventListener('click', () => {
    showSlides(currentSlide - 1);
});

document.querySelector('.next').addEventListener('click', () => {
    showSlides(currentSlide + 1);
});

setInterval(() => {
    showSlides(currentSlide + 1);
}, 5000); // Automatically change slides every 5 seconds
