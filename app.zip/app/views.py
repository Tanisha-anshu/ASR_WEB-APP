from django.shortcuts import render
from django.contrib import messages
from datetime import datetime
from django.core.files.storage import default_storage
from django.core.files.base import ContentFile

import os
os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'

import librosa
from transformers import Wav2Vec2ForCTC, Wav2Vec2Processor
import torch
import soundfile as sf

import warnings
warnings.filterwarnings("ignore", category=FutureWarning, module="tensorflow")


import argparse
from transformers import pipeline
from pathlib import Path

# Define arguments directly in code instead of using argparse
temp_ckpt_folder = "./model/openAI/"  # Temporary folder for loading model files
language = "hi"  # Language code
device = 0  # Device to run the model on

model_id = temp_ckpt_folder
# Load the ASR pipeline
transcribe = pipeline(
    task="automatic-speech-recognition",
    model=model_id,
    chunk_length_s=30,
    device=device,
)

# Set the language for the transcription
transcribe.model.config.forced_decoder_ids = transcribe.tokenizer.get_decoder_prompt_ids(language=language, task="transcribe")

# Load the trained model and processor
model = Wav2Vec2ForCTC.from_pretrained("./model/Wave2Vec/")
processor = Wav2Vec2Processor.from_pretrained("./model/Wave2Vec/")

# Function to transcribe a single audio file
def transcribe_audio(file_path):
    # Load audio file
    speech, sample_rate = sf.read(file_path)

    # Resample the audio to 16000 Hz if necessary
    if sample_rate != 16000:
        speech = librosa.resample(speech, orig_sr=sample_rate, target_sr=16000)

    # Preprocess the audio
    input_values = processor(speech, sampling_rate=16000, return_tensors="pt").input_values

    # Perform inference
    with torch.no_grad():
        logits = model(input_values).logits

    # Decode the predicted ids to text, skipping special tokens
    predicted_ids = torch.argmax(logits, dim=-1)
    transcription = processor.batch_decode(predicted_ids, skip_special_tokens=True)

    return transcription[0]

# Function to transcribe a single audio file
def transcribe_audio(file_path):
    # Load audio file
    speech, sample_rate = sf.read(file_path)

    # Resample the audio to 16000 Hz if necessary
    if sample_rate != 16000:
        speech = librosa.resample(speech, orig_sr=sample_rate, target_sr=16000)

    # Preprocess the audio
    input_values = processor(speech, sampling_rate=16000, return_tensors="pt").input_values

    # Perform inference
    with torch.no_grad():
        logits = model(input_values).logits

    # Decode the predicted ids to text, skipping special tokens
    predicted_ids = torch.argmax(logits, dim=-1)
    transcription = processor.batch_decode(predicted_ids, skip_special_tokens=True)

    return transcription[0]

# Create your views here.
def index(request):
    transcribe_audiovar="t"
    if request.method == 'POST' and request.FILES.get('audioFile'):
        type = request.POST.get("type")
        audioFile = request.FILES['audioFile']
        file_path = default_storage.save(f'audio/{audioFile.name}', ContentFile(audioFile.read()))
        if type=="My Model":
            transcribe_audiovar = transcribe_audio(file_path)
        else:
            transcribe_audiovar = transcribe(file_path)["text"]
        default_storage.delete(f'audio/{audioFile.name}') #delete file after transcription
        # transcribe_audiovar = file_path

    else:
        type="hello"

    # transcribe_audiovar = transcribe_audio("audio/audio_UV3nr0u.wav")
    print(transcribe_audiovar);
    data={
        "text":type,
        "transcribe_audio":transcribe_audiovar
    }

    return render(request, "index.html",data)
